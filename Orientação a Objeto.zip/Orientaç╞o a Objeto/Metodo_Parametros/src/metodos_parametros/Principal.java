import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Principal extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel label;
	Timer timer;
	int current = 0;

	public Principal() {
		this.add(this.getLabel());
		this.go();
	}

	public JLabel getLabel() {
		if (this.label == null) {
			this.label = new JLabel(this.current + "");
			this.label.setPreferredSize(new Dimension(100, 22));
		}
		return this.label;
	}

	public void go() {
		ActionListener action = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				label.setText(++current + "");
			}

			public void actionPerformed2(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		};

	}

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(new Principal());
		frame.setSize(200, 75);
		frame.setVisible(true);
	}
}