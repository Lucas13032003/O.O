package metodos_parametros;

public class MandaMensagem {
	public void enviaMensagem() {
		System.out.println("Bem-vindo ao Brasil");
	}
	public void mandaBoasVindas (String nome, int idade) {
		System.out.printf("Ola, %s, voce"
				+ " tem %d anos de idade", nome, idade);
	}

}
