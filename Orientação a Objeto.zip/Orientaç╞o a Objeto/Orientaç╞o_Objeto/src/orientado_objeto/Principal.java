package orientado_objeto;

public class Principal {

	public static void main(String[] args) {
		Livro livro = new Livro();
		
		livro.nome = "A cabana";
		livro.descrição = "Livros sobre religiao";
		livro.isbn = "12345";
		livro.preco = 47.87;
		livro.autor = "Jose Silvano";
		livro.dataPub = "20/10/2013";
		
		livro.dadosLivro();

	}

}

