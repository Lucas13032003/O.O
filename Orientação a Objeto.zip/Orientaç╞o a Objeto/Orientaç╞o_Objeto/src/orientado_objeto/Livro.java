package orientado_objeto;

public class Livro {
	String nome;
	String descrição;
	String autor;
	String isbn;
	double preco;
	String dataPub;
	
	//void --> Vazio não retorna nada
	void dadosLivro () {
		System.out.println("Nome do livro: " + nome);
		System.out.println("Preco: " + preco);
		System.out.println("Autor: " + autor);
		System.out.println("Data de publicacao: " + dataPub + "\n");
	}
}
