
public class OperadosRelacionais {

	public static void main(String[] args) {
		int x = 10;
		int k = 20;
		System.out.printf("x e igual a 10? %b\n", x == 10);
		System.out.printf("x e diferente de 10? %b\n", x != 10);
		System.out.printf(" x e maior que k? %b\n", x > k);
		System.out.printf(" x e maior ou igual 10? %b\n", x >= 10);
		System.out.printf(" x e menor que 10? %b\n", x < 10);
		System.out.printf(" x e maior ou igual a k? %b\n", x >= k);
	}
	
}
/**
 x e igual a 10? true
 x e diferente de 10? false
 x e maior que k? false
 x e maior ou igual 10? true
 x e menor que 10? false
 x e maior ou igual a k? false
 */
