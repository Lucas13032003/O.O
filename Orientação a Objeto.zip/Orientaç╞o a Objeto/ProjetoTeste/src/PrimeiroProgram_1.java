public class PrimeiroProgram_1 {

	public static void main(String[] args) {
		boolean VouF = true;
		byte a;
		char letra = 'F';
		int valor = 4500;
		double x = 3.14;
		a = 20;
		
		System.out.printf("Valor de VouF (boolean):%b\n", VouF);
		System.out.printf("Valor de a (byte):%d\n", a);
		System.out.printf("Valor de letra (char):%c\n", letra);
		System.out.printf("Valor de valor (int):%d\n", valor);
		System.out.printf("Valor de x (double):%2.2f\n", x);

	}

}

