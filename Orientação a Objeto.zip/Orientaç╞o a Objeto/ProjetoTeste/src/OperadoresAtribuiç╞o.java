
public class OperadoresAtribuição {
	public static void main(String[] args) {
		int numero = 0;
		System.out.println("Valor original " + numero);
		numero += 3;
		System.out.println("Valor de numero = " + numero);
		numero *= 4;
		System.out.println("Valor de numero = " + numero);
		numero /= 2;
		System.out.println("Valor de numero = " + numero);
		numero %= 5;
		System.out.println("Valor de numero = " + numero);
	}
}
