package sobrecarga;

public class Expoente {
	//Método que não caucula nada
	public static void elevar() {
		System.out.println("Este Metodo nao calcula nada");
	}
	// Método que caucula o quadrado de i
	public static double elevar (double i) {
		return i * i;
	}
	// Metodo que caucula o elevado i a j
	public static double elevar (double i, double j) {
		return Math.pow(i, j);
	}

}
