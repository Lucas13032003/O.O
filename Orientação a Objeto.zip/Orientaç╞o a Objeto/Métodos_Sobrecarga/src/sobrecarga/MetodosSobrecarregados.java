package sobrecarga;

public class MetodosSobrecarregados {

	public static void main(String[] args) {
		double a = 3;
		double b = 3;
		
		System.out.printf("O qudrado de %.2f\n e %.2f\n",
				a, Expoente.elevar(a));
		System.out.printf("%.2f elevado a %.2f e "
				+ "%.2f\n",a, b, Expoente.elevar(a,b));
		Expoente.elevar();
		
	}

}
