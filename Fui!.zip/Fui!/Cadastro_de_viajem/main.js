'use strict'

const openModal = () => document.getElementById('modal')
    .classList.add('active')

document.getElementById('cadastrarviajem')
        .addEventListener('click', openModal)