const  map = L.map('map').setView([-15.989200, -48.0443439], 16);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
}).addTo(map);

let isFetching = false

map.on("Click", async e =>{
    if(isFetching) return
    isFetching = true

    const { lat, lng} = e.latlng
    
    const link = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&addressdetails=1&format=jsonv2`

    const data = await fetch(link). then(response => response.json()).catch(error => false)

    console.log(data)
    setTimeout(() => isFetching = false, 1000);
})