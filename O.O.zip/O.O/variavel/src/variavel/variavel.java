package variavel;

public class variavel {
	public static void main (String [] args){
		String nome = "lucas";
		int idade= 19;
		boolean casado = true;
		System.out.println("nome");
	}

}
