/**
 * 
 */
/**
 * @author lucas
 *
 */
module App_Figurinhas {
}