package exercicio_1;

public class exercicio_1 {
	/**
	 * Program que imprime em tela "Olá Mundo"
	 * @author lucas
	 */
	
	public static void main (String [] args) {
		System.out.println("Ola Mundo");//Primeira linha
		System.out.println("Meu primeiro program em Java!"); //Segunda linha
	}
	

}
	{/** New commit*/
		
	}