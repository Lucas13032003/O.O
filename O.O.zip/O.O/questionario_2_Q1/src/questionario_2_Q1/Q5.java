package questionario_2_Q1;
import java . util . Scanner ;

public class Q5 {
	public static void main(String[] args) {
		int n1;
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o numero:");
		n1 = entrada.nextInt();
		
		if (n1 % 2 == 0) {
			System.out.println("true");
		}	else {
			System.out.println("false");
		}
	}
}

