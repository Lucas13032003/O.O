package questionario_2_Q1;

public class Q1 {

	public static void main(String[] args) {
		double a1 =  1.58;
		double a2 = 2.07;
		double a3 = 0.55;
		double media = ((a1+a2+a3)/3);
		System.out.println(media);
	}

}
