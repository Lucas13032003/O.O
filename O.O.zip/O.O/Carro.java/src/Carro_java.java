public class Carro_java {
	String marca;
	String cor;
	int numPortas;
	int ano;
	boolean movimento;
	
	public Carro_java (String marca, String cor, int n, int a, 
			boolean mov) {
		this.marca = marca;
		this.cor = cor;
		numPortas = n;
		ano = a;
		movimento = mov;
	}
	public String getMarcas() {
		return marca;
	}
	public void setMarca() {
		
	}

}
